package OOP_Exercise_4;

public class Test_4_4 {
    public static void main(String[] args) {
        MovablePoint p1 = new MovablePoint(3,5,10,30);
        System.out.println(p1);
    }
}
