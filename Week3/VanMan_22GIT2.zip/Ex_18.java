package Week3;

public class Ex_18 {
    public static void main(String[] args) {
        System.out.println("1,7,16,37,79,173,...");
        System.out.println("Em chịu chết");
    }
}
