package Week3;

public class ex_8 extends ex_support {
    public static void main(String[] args) {
        int i = 100;
        System.out.println((double)sum(i)/ 100);
    } 
}
