package Week3;

public class ex_22 extends ex_support {
    public static void main(String[] args) {
        for (int i = 0; i <= 511; i++) {
            System.out.println(convert8(i));
        }
    }
}
