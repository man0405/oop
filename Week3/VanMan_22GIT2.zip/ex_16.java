package Week3;

public class ex_16 {
    public static void main(String[] args) {
        int a = 0;
        System.out.print(a + ", ");
        for (int i = 1 ; i <  10 ; i++) {
            a = a + 2*i + 1;
            System.out.print(a + ", ");
        }
    }
}
