package Week3;


public class ex_7 extends ex_support {
    public static void main(String[] args) {
        int i = 100;
        // ex_7_1support a = new ex_7_1support();
        System.out.println(sum(i));

    }
}
